package com.audiolab.dspplayer.eq

object EqualizerPresets {

    data class Preset(
        val name: String,
        val bands: ShortArray,   // up to 10 bands
        val bassBoost: Short,
        val virtualizer: Short
    )

    fun getAllPresets(): List<Preset> = listOf(
        Preset("Normal",         shortArrayOf(0,0,0,0,0,0,0,0,0,0),                    0,    0),
        Preset("Music",          shortArrayOf(300,200,100,0,100,200,200,300,300,200),   300,  400),
        Preset("Rock",           shortArrayOf(500,400,200,-100,0,100,400,400,500,400),  600,  500),
        Preset("Pop",            shortArrayOf(-200,100,300,400,300,200,100,0,-100,-200),400,  300),
        Preset("Jazz",           shortArrayOf(300,200,100,-100,0,100,200,300,400,300),  200,  600),
        Preset("Classical",      shortArrayOf(400,300,200,0,-100,0,100,200,300,400),    0,    700),
        Preset("Heavy Metal",    shortArrayOf(600,500,300,-200,-100,0,300,400,500,600), 800,  400),
        Preset("EDM",            shortArrayOf(500,400,200,0,100,200,300,400,500,400),   900,  800),
        Preset("Hip Hop",        shortArrayOf(600,500,300,100,0,0,0,100,200,100),       1000, 300),
        Preset("Vocal Clarity",  shortArrayOf(-300,-200,-100,300,500,400,300,200,100,0),0,    100),
        Preset("Bass Boost",     shortArrayOf(1000,800,600,400,200,0,0,0,0,0),          1000, 0),
        Preset("Treble Boost",   shortArrayOf(0,0,0,0,100,200,400,600,700,800),         0,    0),
        Preset("Cinema Mode",    shortArrayOf(400,300,200,100,100,200,300,300,400,400), 500,  1000),
        Preset("Dolby Atmos 3D", shortArrayOf(300,200,100,100,200,200,300,300,400,400), 400,  1000),
        Preset("Live Concert",   shortArrayOf(300,200,100,0,100,200,300,300,400,300),   300,  900),
        Preset("Studio Monitor", shortArrayOf(0,0,0,0,0,0,0,0,0,0),                    0,    0),
        Preset("Gaming FPS",     shortArrayOf(0,0,100,200,400,500,600,700,500,300),     100,  800),
        Preset("Late Night",     shortArrayOf(-200,-100,0,100,100,100,0,-100,-200,-200),200,  0),
        Preset("Acoustic",       shortArrayOf(400,300,200,100,0,100,200,200,300,200),   100,  200),
        Preset("Old Radio",      shortArrayOf(-200,0,300,400,500,400,200,0,-200,-600),  300,  0),
        Preset("Hall Reverb",    shortArrayOf(400,300,200,100,0,100,200,200,300,400),   200,  1000)
    )
}
