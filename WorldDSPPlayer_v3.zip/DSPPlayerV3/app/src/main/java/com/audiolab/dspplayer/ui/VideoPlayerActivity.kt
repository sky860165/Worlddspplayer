package com.audiolab.dspplayer.ui

import android.app.PictureInPictureParams
import android.content.*
import android.os.*
import android.util.Rational
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.*
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.ui.PlayerView
import com.audiolab.dspplayer.model.VideoFile
import com.audiolab.dspplayer.service.VideoService

@UnstableApi
class VideoPlayerActivity : AppCompatActivity() {

    private lateinit var playerView: PlayerView
    private var exoPlayer: ExoPlayer? = null
    private var trackSelector: DefaultTrackSelector? = null
    private var videoService: VideoService? = null
    private var isBound = false

    private var videoList: List<VideoFile> = emptyList()
    private var currentIndex = 0

    // ── UI widgets ──────────────────────────────────────────────────────────
    private lateinit var tvTitle: TextView
    private lateinit var tvResolution: TextView
    private lateinit var btnPip: Button
    private lateinit var btnPrev: Button
    private lateinit var btnNext: Button
    private lateinit var btnSpeed: Button
    private lateinit var btnLock: Button
    private lateinit var btnAspect: Button
    private lateinit var controlBar: LinearLayout

    private var isLocked = false
    private var currentSpeed = 1.0f
    private val speeds = floatArrayOf(0.25f, 0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f, 3.0f)
    private var speedIndex = 3
    private var currentAspect = 0  // 0=FIT, 1=FILL, 2=ZOOM

    private val serviceConn = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName?, b: IBinder?) {
            videoService = (b as VideoService.VideoBinder).getService()
            isBound = true
            // hand the service player to the PlayerView
            playerView.player = videoService?.player
            startPlayback()
        }
        override fun onServiceDisconnected(n: ComponentName?) { isBound = false }
    }

    // ── Lifecycle ────────────────────────────────────────────────────────────
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        hideSystemUI()
        buildUI()
        bindVideoService()
        videoList = VideoListActivity.videoList
        currentIndex = intent.getIntExtra(VideoListActivity.EXTRA_VIDEO_LIST, 0)
    }

    private fun bindVideoService() {
        val i = Intent(this, VideoService::class.java)
        startService(i)
        bindService(i, serviceConn, Context.BIND_AUTO_CREATE)
    }

    // ── Build full-screen UI programmatically ───────────────────────────────
    private fun buildUI() {
        val root = FrameLayout(this).apply {
            setBackgroundColor(0xFF000000.toInt())
        }

        // ExoPlayer view
        playerView = PlayerView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            useController = true      // built-in ExoPlayer controller
            controllerAutoShow = true
            controllerHideOnTouch = true
        }
        root.addView(playerView)

        // Top overlay bar
        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(24, 48, 24, 16)
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
            )
            setBackgroundColor(0x99000000.toInt())
        }

        tvTitle = TextView(this).apply {
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        tvResolution = TextView(this).apply {
            textSize = 12f
            setTextColor(0xFFE040FB.toInt())
            setPadding(8, 4, 8, 4)
            setBackgroundColor(0x33E040FB)
        }
        topBar.addView(tvTitle)
        topBar.addView(tvResolution)
        root.addView(topBar)

        // Bottom control bar
        controlBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(16, 16, 16, 40)
            setBackgroundColor(0x99000000.toInt())
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM
            )
        }

        btnPrev   = makeBtn("⏮")
        btnSpeed  = makeBtn("1.0x")
        btnAspect = makeBtn("⬜ Fit")
        btnLock   = makeBtn("🔓")
        btnPip    = makeBtn("⧉ PiP")
        btnNext   = makeBtn("⏭")

        for (b in listOf(btnPrev, btnSpeed, btnAspect, btnLock, btnPip, btnNext))
            controlBar.addView(b)
        root.addView(controlBar)

        setContentView(root)
        setupListeners()
    }

    private fun makeBtn(label: String) = Button(this).apply {
        text = label
        textSize = 12f
        setTextColor(0xFFFFFFFF.toInt())
        setBackgroundColor(0x55FFFFFF)
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).also { it.setMargins(6, 0, 6, 0) }
        setPadding(20, 12, 20, 12)
    }

    private fun setupListeners() {
        btnPrev.setOnClickListener {
            if (videoList.isNotEmpty()) {
                currentIndex = if (currentIndex > 0) currentIndex - 1 else videoList.size - 1
                startPlayback()
            }
        }
        btnNext.setOnClickListener {
            if (videoList.isNotEmpty()) {
                currentIndex = (currentIndex + 1) % videoList.size
                startPlayback()
            }
        }
        btnSpeed.setOnClickListener {
            speedIndex = (speedIndex + 1) % speeds.size
            currentSpeed = speeds[speedIndex]
            exoPlayer?.setPlaybackSpeed(currentSpeed)
            videoService?.player?.setPlaybackSpeed(currentSpeed)
            btnSpeed.text = "${currentSpeed}x"
        }
        btnLock.setOnClickListener {
            isLocked = !isLocked
            btnLock.text = if (isLocked) "🔒" else "🔓"
            val vis = if (isLocked) View.GONE else View.VISIBLE
            btnPrev.visibility    = vis
            btnNext.visibility    = vis
            btnSpeed.visibility   = vis
            btnAspect.visibility  = vis
            btnPip.visibility     = vis
            playerView.useController = !isLocked
        }
        btnAspect.setOnClickListener {
            currentAspect = (currentAspect + 1) % 3
            when (currentAspect) {
                0 -> { playerView.resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT;  btnAspect.text = "⬜ Fit" }
                1 -> { playerView.resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FILL; btnAspect.text = "▣ Fill" }
                2 -> { playerView.resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_ZOOM; btnAspect.text = "🔍 Zoom" }
            }
        }
        btnPip.setOnClickListener { enterPiP() }
    }

    // ── Playback ─────────────────────────────────────────────────────────────
    private fun startPlayback() {
        val video = videoList.getOrNull(currentIndex) ?: return
        tvTitle.text = video.title
        tvResolution.text = video.resolution()
        VideoService.currentTitle = video.title

        val svc = videoService
        if (svc != null) {
            svc.playUri(video.uri.toString(), video.title)
            playerView.player = svc.player
        } else {
            // Fallback: local ExoPlayer (no background)
            buildLocalPlayer(video)
        }
    }

    private fun buildLocalPlayer(video: VideoFile) {
        exoPlayer?.release()
        trackSelector = DefaultTrackSelector(this).apply {
            // Prefer highest quality track for 4K
            setParameters(buildUponParameters().setMaxVideoSize(Int.MAX_VALUE, Int.MAX_VALUE))
        }
        exoPlayer = ExoPlayer.Builder(this)
            .setTrackSelector(trackSelector!!)
            .build().also { player ->
                playerView.player = player
                player.setMediaItem(MediaItem.fromUri(video.uri))
                player.prepare()
                player.play()
            }
    }

    // ── Picture-in-Picture ──────────────────────────────────────────────────
    private fun enterPiP() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val params = PictureInPictureParams.Builder()
                .setAspectRatio(Rational(16, 9))
                .build()
            enterPictureInPictureMode(params)
            controlBar.visibility = View.GONE
        } else {
            Toast.makeText(this, "PiP not supported on this device", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onPictureInPictureModeChanged(isInPiP: Boolean, newConfig: android.content.res.Configuration) {
        super.onPictureInPictureModeChanged(isInPiP, newConfig)
        controlBar.visibility = if (isInPiP) View.GONE else View.VISIBLE
        playerView.useController = !isInPiP
    }

    // Auto-enter PiP when home button pressed (background playback continues)
    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            && (videoService?.player?.isPlaying == true || exoPlayer?.isPlaying == true)) {
            enterPiP()
        }
    }

    private fun hideSystemUI() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            or View.SYSTEM_UI_FLAG_FULLSCREEN
            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        )
    }

    // ── Cleanup ───────────────────────────────────────────────────────────────
    override fun onStop() {
        super.onStop()
        // Don't release — VideoService keeps playing in background
        if (!isInPictureInPictureMode) {
            exoPlayer?.pause()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        exoPlayer?.release()
        exoPlayer = null
        if (isBound) { unbindService(serviceConn); isBound = false }
    }
}
