package com.audiolab.dspplayer.util

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import com.audiolab.dspplayer.model.VideoFile

object VideoLoader {

    fun loadAllVideos(context: Context): List<VideoFile> {
        val videos = mutableListOf<VideoFile>()

        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.TITLE,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.WIDTH,
            MediaStore.Video.Media.HEIGHT,
            MediaStore.Video.Media.DATA
        )

        // Only videos longer than 5 seconds
        val selection = "${MediaStore.Video.Media.DURATION} > 5000"
        val sortOrder = "${MediaStore.Video.Media.DATE_ADDED} DESC"

        context.contentResolver.query(
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
            projection, selection, null, sortOrder
        )?.use { cursor ->
            val idCol       = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
            val titleCol    = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.TITLE)
            val nameCol     = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
            val durCol      = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
            val sizeCol     = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
            val wCol        = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.WIDTH)
            val hCol        = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.HEIGHT)
            val pathCol     = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA)

            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val uri = ContentUris.withAppendedId(
                    MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id
                )
                val thumbUri = Uri.parse(
                    "content://media/external/video/media/$id/thumbnail"
                )

                videos.add(
                    VideoFile(
                        id          = id,
                        title       = cursor.getString(titleCol) ?: "Unknown",
                        displayName = cursor.getString(nameCol) ?: "Unknown",
                        duration    = cursor.getLong(durCol),
                        size        = cursor.getLong(sizeCol),
                        width       = cursor.getInt(wCol),
                        height      = cursor.getInt(hCol),
                        uri         = uri,
                        thumbnailUri = thumbUri,
                        path        = cursor.getString(pathCol) ?: ""
                    )
                )
            }
        }
        return videos
    }
}
