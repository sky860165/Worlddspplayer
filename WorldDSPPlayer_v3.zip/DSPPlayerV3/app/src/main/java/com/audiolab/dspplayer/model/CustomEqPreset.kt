package com.audiolab.dspplayer.model

data class CustomEqPreset(
    val name: String,
    val bands: List<Int>,         // 10 bands in milliBels
    val bassBoost: Int,
    val virtualizer: Int,
    val reverb: Int,
    val balance: Int,             // -100 to 100
    val speed: Float              // 0.5f to 2.0f
)
