package com.audiolab.dspplayer.ui

import android.content.*
import android.os.Bundle
import android.os.IBinder
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.audiolab.dspplayer.R
import com.audiolab.dspplayer.databinding.ActivityPlaylistBinding
import com.audiolab.dspplayer.model.Song
import com.audiolab.dspplayer.player.PlayerState
import com.audiolab.dspplayer.service.MusicService

class PlaylistActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPlaylistBinding
    private var musicService: MusicService? = null
    private var isBound = false
    private lateinit var adapter: SongAdapter
    private var filteredSongs = mutableListOf<Song>()

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            musicService = (binder as MusicService.MusicBinder).getService()
            isBound = true
        }
        override fun onServiceDisconnected(name: ComponentName?) { isBound = false }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPlaylistBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.title = "🎵 Playlist"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        bindService(Intent(this, MusicService::class.java), connection, Context.BIND_AUTO_CREATE)

        filteredSongs = PlayerState.playlist.toMutableList()
        adapter = SongAdapter(filteredSongs) { song, index ->
            val realIndex = PlayerState.playlist.indexOf(song)
            PlayerState.currentIndex = realIndex
            musicService?.playSong(song)
            Toast.makeText(this, "▶ ${song.title}", Toast.LENGTH_SHORT).show()
        }

        binding.recyclerSongs.layoutManager = LinearLayoutManager(this)
        binding.recyclerSongs.adapter = adapter

        binding.tvSongCount.text = "${PlayerState.playlist.size} songs"

        binding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                val q = s.toString().lowercase()
                filteredSongs.clear()
                filteredSongs.addAll(
                    if (q.isEmpty()) PlayerState.playlist
                    else PlayerState.playlist.filter {
                        it.title.lowercase().contains(q) || it.artist.lowercase().contains(q)
                    }
                )
                adapter.notifyDataSetChanged()
                binding.tvSongCount.text = "${filteredSongs.size} songs"
            }
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        })

        // Sort options
        binding.spinnerSort.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            arrayOf("Title A-Z", "Title Z-A", "Artist", "Duration ↑", "Duration ↓")
        )
        binding.spinnerSort.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) {
                val sorted = when (pos) {
                    0 -> PlayerState.playlist.sortedBy { it.title }
                    1 -> PlayerState.playlist.sortedByDescending { it.title }
                    2 -> PlayerState.playlist.sortedBy { it.artist }
                    3 -> PlayerState.playlist.sortedBy { it.duration }
                    4 -> PlayerState.playlist.sortedByDescending { it.duration }
                    else -> PlayerState.playlist
                }
                filteredSongs.clear(); filteredSongs.addAll(sorted)
                adapter.notifyDataSetChanged()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    inner class SongAdapter(
        private val songs: List<Song>,
        private val onClick: (Song, Int) -> Unit
    ) : RecyclerView.Adapter<SongAdapter.VH>() {

        inner class VH(view: View) : RecyclerView.ViewHolder(view) {
            val tvTitle: TextView = view.findViewById(R.id.tvSongItemTitle)
            val tvSub: TextView = view.findViewById(R.id.tvSongItemSub)
            val tvDur: TextView = view.findViewById(R.id.tvSongItemDuration)
            val container: View = view
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_song, parent, false)
            return VH(v)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            val song = songs[position]
            val isCurrent = PlayerState.currentSong?.id == song.id
            holder.tvTitle.text = song.title
            holder.tvTitle.setTextColor(if (isCurrent) 0xFFBB86FC.toInt() else 0xFFFFFFFF.toInt())
            holder.tvSub.text = "${song.artist} • ${song.album}"
            holder.tvDur.text = song.formattedDuration()
            holder.container.setBackgroundColor(if (isCurrent) 0xFF1E1E3A.toInt() else 0xFF1A1A2E.toInt())
            holder.container.setOnClickListener { onClick(song, position) }
        }

        override fun getItemCount() = songs.size
    }

    override fun onSupportNavigateUp(): Boolean { onBackPressedDispatcher.onBackPressed(); return true }

    override fun onDestroy() {
        super.onDestroy()
        if (isBound) { unbindService(connection); isBound = false }
    }
}
