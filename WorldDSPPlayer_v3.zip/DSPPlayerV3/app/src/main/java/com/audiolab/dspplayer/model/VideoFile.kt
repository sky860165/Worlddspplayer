package com.audiolab.dspplayer.model

import android.net.Uri

data class VideoFile(
    val id: Long,
    val title: String,
    val displayName: String,
    val duration: Long,      // ms
    val size: Long,          // bytes
    val width: Int,
    val height: Int,
    val uri: Uri,
    val thumbnailUri: Uri?,
    val path: String
) {
    fun formattedDuration(): String {
        val totalSec = duration / 1000
        val h = totalSec / 3600
        val m = (totalSec % 3600) / 60
        val s = totalSec % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
    }

    fun formattedSize(): String {
        val mb = size / (1024.0 * 1024.0)
        return if (mb >= 1024) "%.1f GB".format(mb / 1024) else "%.1f MB".format(mb)
    }

    fun resolution(): String {
        return when {
            width >= 3840 || height >= 2160 -> "4K UHD"
            width >= 2560 || height >= 1440 -> "2K QHD"
            width >= 1920 || height >= 1080 -> "1080p FHD"
            width >= 1280 || height >= 720  -> "720p HD"
            else -> "${width}x${height}"
        }
    }

    fun is4K(): Boolean = width >= 3840 || height >= 2160
}
