package com.audiolab.dspplayer.ui

import android.content.*
import android.os.Bundle
import android.os.IBinder
import android.view.LayoutInflater
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.audiolab.dspplayer.R
import com.audiolab.dspplayer.databinding.ActivityEqualizerBinding
import com.audiolab.dspplayer.eq.EqualizerPresets
import com.audiolab.dspplayer.model.CustomEqPreset
import com.audiolab.dspplayer.service.MusicService
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class EqualizerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityEqualizerBinding
    private var musicService: MusicService? = null
    private var isBound = false

    private val bandLabels = listOf("32Hz","64Hz","125Hz","250Hz","500Hz","1K","2K","4K","8K","16K")
    private val bandSeekBars = mutableListOf<SeekBar>()

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            musicService = (binder as MusicService.MusicBinder).getService()
            isBound = true
            refreshBandUI()
        }
        override fun onServiceDisconnected(name: ComponentName?) { isBound = false }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEqualizerBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.title = "🎛️ Equalizer"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        bindService(Intent(this, MusicService::class.java), connection, Context.BIND_AUTO_CREATE)

        setupBuiltinPresets()
        setupCustomPresets()
        buildBandSliders()
        setupEffectSliders()
        setupButtons()
    }

    private fun setupBuiltinPresets() {
        val presets = EqualizerPresets.getAllPresets().map { it.name }
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, presets)
        binding.spinnerBuiltinPresets.adapter = adapter
        binding.btnApplyBuiltin.setOnClickListener {
            val name = binding.spinnerBuiltinPresets.selectedItem.toString()
            val preset = EqualizerPresets.getAllPresets().find { it.name == name } ?: return@setOnClickListener
            musicService?.applyBuiltinPreset(preset)
            refreshBandUI()
            binding.seekBass.progress = preset.bassBoost.toInt()
            binding.seekVirtualizer.progress = preset.virtualizer.toInt()
            binding.tvBass.text = "Bass Boost: ${preset.bassBoost}"
            binding.tvVirtualizer.text = "3D/Virtualizer: ${preset.virtualizer}"
            Toast.makeText(this, "✅ ${preset.name} Applied!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setupCustomPresets() {
        refreshCustomPresetSpinner()
        binding.btnApplyCustom.setOnClickListener {
            val name = binding.spinnerCustomPresets.selectedItem?.toString() ?: return@setOnClickListener
            val preset = musicService?.eqManager?.loadAllCustomPresets()?.find { it.name == name } ?: return@setOnClickListener
            musicService?.applyCustomPreset(preset)
            refreshBandUI()
            Toast.makeText(this, "✅ $name Applied!", Toast.LENGTH_SHORT).show()
        }
        binding.btnDeleteCustom.setOnClickListener {
            val name = binding.spinnerCustomPresets.selectedItem?.toString() ?: return@setOnClickListener
            MaterialAlertDialogBuilder(this)
                .setTitle("Delete Preset")
                .setMessage("Delete \"$name\"?")
                .setPositiveButton("Delete") { _, _ ->
                    musicService?.eqManager?.deleteCustomPreset(name)
                    refreshCustomPresetSpinner()
                    Toast.makeText(this, "Deleted!", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    private fun refreshCustomPresetSpinner() {
        val customList = musicService?.eqManager?.loadAllCustomPresets()?.map { it.name } ?: emptyList()
        val display = if (customList.isEmpty()) listOf("No saved presets") else customList
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, display)
        binding.spinnerCustomPresets.adapter = adapter
        binding.btnApplyCustom.isEnabled = customList.isNotEmpty()
        binding.btnDeleteCustom.isEnabled = customList.isNotEmpty()
    }

    private fun buildBandSliders() {
        bandSeekBars.clear()
        binding.llBands.removeAllViews()
        val inflater = LayoutInflater.from(this)

        for (i in bandLabels.indices) {
            val row = inflater.inflate(R.layout.item_eq_band, binding.llBands, false)
            val tvLabel = row.findViewById<TextView>(R.id.tvBandLabel)
            val seek = row.findViewById<SeekBar>(R.id.seekBand)
            val tvVal = row.findViewById<TextView>(R.id.tvBandValue)

            tvLabel.text = bandLabels[i]
            seek.max = 3000   // -1500 to +1500 mapped 0-3000
            seek.progress = 1500
            tvVal.text = "0"

            seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    val mb = p - 1500
                    tvVal.text = "${if (mb >= 0) "+" else ""}$mb"
                    if (fromUser) musicService?.eqManager?.setBandLevel(i, mb.toShort().toInt())
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
            bandSeekBars.add(seek)
            binding.llBands.addView(row)
        }
    }

    private fun setupEffectSliders() {
        binding.seekBass.max = 1000
        binding.seekBass.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                binding.tvBass.text = "Bass Boost: $p"
                if (fromUser) musicService?.eqManager?.setBassBoost(p)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        binding.seekVirtualizer.max = 1000
        binding.seekVirtualizer.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                binding.tvVirtualizer.text = "3D/Virtualizer: $p"
                if (fromUser) musicService?.eqManager?.setVirtualizer(p)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        // Reverb presets
        val reverbOptions = arrayOf("None","Large Room","Medium Room","Small Room","Large Hall","Medium Hall","Plate")
        val reverbAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, reverbOptions)
        binding.spinnerReverb.adapter = reverbAdapter
        binding.spinnerReverb.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, pos: Int, id: Long) {
                musicService?.eqManager?.setReverb(pos.toShort())
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    private fun setupButtons() {
        binding.btnReset.setOnClickListener {
            bandSeekBars.forEachIndexed { i, seek ->
                seek.progress = 1500
                musicService?.eqManager?.setBandLevel(i, 0)
            }
            binding.seekBass.progress = 0
            binding.seekVirtualizer.progress = 0
            musicService?.eqManager?.setBassBoost(0)
            musicService?.eqManager?.setVirtualizer(0)
            Toast.makeText(this, "Reset to Flat", Toast.LENGTH_SHORT).show()
        }

        binding.btnSavePreset.setOnClickListener { showSaveDialog() }
    }

    private fun showSaveDialog() {
        val input = EditText(this).apply {
            hint = "Preset name (e.g. My Rock)"
            setPadding(48, 24, 48, 24)
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("💾 Save Custom Preset")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isEmpty()) { Toast.makeText(this, "Enter a name!", Toast.LENGTH_SHORT).show(); return@setPositiveButton }
                val bands = bandSeekBars.map { it.progress - 1500 }
                val preset = CustomEqPreset(
                    name = name,
                    bands = bands,
                    bassBoost = binding.seekBass.progress,
                    virtualizer = binding.seekVirtualizer.progress,
                    reverb = binding.spinnerReverb.selectedItemPosition,
                    balance = 0,
                    speed = 1.0f
                )
                musicService?.eqManager?.saveCustomPreset(preset)
                refreshCustomPresetSpinner()
                Toast.makeText(this, "✅ \"$name\" Saved!", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun refreshBandUI() {
        val bands = musicService?.eqManager?.getCurrentBands() ?: return
        bands.forEachIndexed { i, mb ->
            if (i < bandSeekBars.size) bandSeekBars[i].progress = (mb + 1500).coerceIn(0, 3000)
        }
    }

    override fun onSupportNavigateUp(): Boolean { onBackPressedDispatcher.onBackPressed(); return true }

    override fun onDestroy() {
        super.onDestroy()
        if (isBound) { unbindService(connection); isBound = false }
    }
}
