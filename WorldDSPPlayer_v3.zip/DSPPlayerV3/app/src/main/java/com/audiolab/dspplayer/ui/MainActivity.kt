package com.audiolab.dspplayer.ui

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.audiolab.dspplayer.R
import com.audiolab.dspplayer.databinding.ActivityMainBinding
import com.audiolab.dspplayer.player.PlayerState
import com.audiolab.dspplayer.service.MusicService
import com.audiolab.dspplayer.util.SongLoader
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.slider.Slider

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var musicService: MusicService? = null
    private var isBound = false
    private var isDark = true

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            val b = binder as MusicService.MusicBinder
            musicService = b.getService()
            isBound = true
            musicService?.onPlaybackChanged = { runOnUiThread { updatePlaybackUI() } }
            musicService?.onProgressUpdate = { pos, dur -> runOnUiThread { updateProgress(pos, dur) } }
        }
        override fun onServiceDisconnected(name: ComponentName?) { isBound = false }
    }

    companion object {
        private const val PERM_CODE = 200
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        startAndBindService()
        setupClickListeners()
        checkPermissions()
        applyTheme(isDark)
    }

    private fun startAndBindService() {
        val intent = Intent(this, MusicService::class.java)
        startService(intent)
        bindService(intent, connection, Context.BIND_AUTO_CREATE)
    }

    private fun checkPermissions() {
        val perms = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (!hasPermission(Manifest.permission.READ_MEDIA_AUDIO))
                perms.add(Manifest.permission.READ_MEDIA_AUDIO)
            if (!hasPermission(Manifest.permission.POST_NOTIFICATIONS))
                perms.add(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            if (!hasPermission(Manifest.permission.READ_EXTERNAL_STORAGE))
                perms.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        if (perms.isNotEmpty()) ActivityCompat.requestPermissions(this, perms.toTypedArray(), PERM_CODE)
        else loadSongs()
    }

    private fun hasPermission(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERM_CODE) loadSongs()
    }

    private fun loadSongs() {
        val songs = SongLoader.loadAllSongs(this)
        PlayerState.playlist = songs.toMutableList()
        updateSongInfo()
        if (songs.isEmpty()) {
            binding.tvSongTitle.text = "No songs found"
            binding.tvArtist.text = "Add songs to device storage"
        }
    }

    private fun setupClickListeners() {
        binding.btnPlay.setOnClickListener {
            val svc = musicService ?: return@setOnClickListener
            if (PlayerState.playlist.isEmpty()) {
                Toast.makeText(this, "No songs found!", Toast.LENGTH_SHORT).show(); return@setOnClickListener
            }
            if (svc.isPlaying()) svc.pause()
            else {
                if (PlayerState.currentSong == null) {
                    PlayerState.currentIndex = 0
                    svc.playSong(PlayerState.playlist[0])
                } else svc.play()
            }
        }

        binding.btnNext.setOnClickListener { musicService?.next() }
        binding.btnPrev.setOnClickListener { musicService?.previous() }

        binding.btnShuffle.setOnClickListener {
            PlayerState.isShuffled = !PlayerState.isShuffled
            binding.btnShuffle.alpha = if (PlayerState.isShuffled) 1f else 0.4f
            Toast.makeText(this, if (PlayerState.isShuffled) "Shuffle ON" else "Shuffle OFF", Toast.LENGTH_SHORT).show()
        }

        binding.btnRepeat.setOnClickListener {
            PlayerState.repeatMode = when (PlayerState.repeatMode) {
                PlayerState.RepeatMode.NONE -> PlayerState.RepeatMode.ALL
                PlayerState.RepeatMode.ALL  -> PlayerState.RepeatMode.ONE
                PlayerState.RepeatMode.ONE  -> PlayerState.RepeatMode.NONE
            }
            binding.btnRepeat.text = when (PlayerState.repeatMode) {
                PlayerState.RepeatMode.NONE -> "🔁"
                PlayerState.RepeatMode.ALL  -> "🔁All"
                PlayerState.RepeatMode.ONE  -> "🔂"
            }
        }

        binding.btnEqualizer.setOnClickListener {
            startActivity(Intent(this, EqualizerActivity::class.java))
        }

        binding.btnPlaylist.setOnClickListener {
            startActivity(Intent(this, PlaylistActivity::class.java))
        }

        // ▶ NEW: 4K Video Player button
        binding.btnVideo.setOnClickListener {
            startActivity(Intent(this, VideoListActivity::class.java))
        }

        binding.btnSleepTimer.setOnClickListener { showSleepTimerDialog() }
        binding.btnSpeed.setOnClickListener { showSpeedDialog() }

        binding.btnTheme.setOnClickListener {
            isDark = !isDark
            applyTheme(isDark)
        }

        binding.seekProgress.addOnChangeListener { _, value, fromUser ->
            if (fromUser) musicService?.seekTo(value.toInt())
        }

        binding.seekBalance.addOnChangeListener { _, value, fromUser ->
            if (fromUser) {
                musicService?.updateBalance(value / 100f)
                binding.tvBalance.text = when {
                    value < -5 -> "Balance: L${(-value).toInt()}"
                    value > 5  -> "Balance: R${value.toInt()}"
                    else       -> "Balance: Center"
                }
            }
        }

        binding.visualizerView.setOnClickListener { binding.visualizerView.toggleMode() }
    }

    private fun updatePlaybackUI() {
        val playing = musicService?.isPlaying() ?: false
        binding.btnPlay.text = if (playing) "⏸" else "▶"
        updateSongInfo()
    }

    private fun updateSongInfo() {
        val song = PlayerState.currentSong ?: return
        binding.tvSongTitle.text = song.title
        binding.tvArtist.text = "${song.artist} • ${song.album}"
        binding.tvDuration.text = song.formattedDuration()
    }

    private fun updateProgress(pos: Int, dur: Int) {
        if (dur > 0) {
            binding.seekProgress.valueTo = dur.toFloat().coerceAtLeast(1f)
            binding.seekProgress.value = pos.toFloat().coerceIn(0f, dur.toFloat())
            binding.tvPosition.text = formatMs(pos)
            binding.tvDuration.text = formatMs(dur)
        }
    }

    private fun formatMs(ms: Int): String {
        val s = ms / 1000; return "%d:%02d".format(s / 60, s % 60)
    }

    private fun showSleepTimerDialog() {
        val options = arrayOf("5 min", "10 min", "15 min", "30 min", "60 min", "Cancel")
        val mins = intArrayOf(5, 10, 15, 30, 60, 0)
        MaterialAlertDialogBuilder(this)
            .setTitle("💤 Sleep Timer")
            .setItems(options) { _, i ->
                if (mins[i] > 0) {
                    musicService?.setSleepTimer(mins[i])
                    Toast.makeText(this, "Timer set: ${options[i]}", Toast.LENGTH_SHORT).show()
                } else musicService?.cancelSleepTimer()
            }.show()
    }

    private fun showSpeedDialog() {
        val speeds = floatArrayOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f)
        val labels = speeds.map { "${it}x" }.toTypedArray()
        MaterialAlertDialogBuilder(this)
            .setTitle("⚡ Playback Speed")
            .setItems(labels) { _, i ->
                musicService?.updateSpeed(speeds[i])
                binding.btnSpeed.text = "${speeds[i]}x"
            }.show()
    }

    private fun applyTheme(dark: Boolean) {
        val bg   = if (dark) 0xFF121212.toInt() else 0xFFF5F5F5.toInt()
        val text = if (dark) 0xFFFFFFFF.toInt() else 0xFF121212.toInt()
        binding.root.setBackgroundColor(bg)
        binding.tvSongTitle.setTextColor(text)
        binding.tvArtist.setTextColor(if (dark) 0xFF9E9E9E.toInt() else 0xFF616161.toInt())
        binding.btnTheme.text = if (dark) "☀️" else "🌙"
    }

    override fun onResume() {
        super.onResume()
        updatePlaybackUI()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isBound) { unbindService(connection); isBound = false }
    }
}
