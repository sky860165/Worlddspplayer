package com.audiolab.dspplayer.ui

import android.content.Context
import android.graphics.*
import android.media.audiofx.Visualizer
import android.util.AttributeSet
import android.view.View
import kotlin.math.abs

class VisualizerView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyle: Int = 0
) : View(context, attrs, defStyle) {

    private var visualizer: Visualizer? = null
    private var fftData: ByteArray = ByteArray(0)
    private var waveData: ByteArray = ByteArray(0)

    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val gradientColors = intArrayOf(
        Color.parseColor("#03DAC6"),
        Color.parseColor("#BB86FC"),
        Color.parseColor("#CF6679")
    )

    private var barCount = 64
    private var isWaveMode = false

    fun setupVisualizer(sessionId: Int) {
        try {
            visualizer?.release()
            visualizer = Visualizer(sessionId).apply {
                captureSize = Visualizer.getCaptureSizeRange()[1]
                setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                    override fun onWaveFormDataCapture(v: Visualizer, wfm: ByteArray, sr: Int) {
                        waveData = wfm.clone()
                        postInvalidate()
                    }
                    override fun onFftDataCapture(v: Visualizer, fft: ByteArray, sr: Int) {
                        fftData = fft.clone()
                        postInvalidate()
                    }
                }, Visualizer.getMaxCaptureRate() / 2, true, true)
                enabled = true
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun toggleMode() { isWaveMode = !isWaveMode }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.parseColor("#1A1A2E"))

        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2
        val cy = h / 2

        if (isWaveMode) drawWave(canvas, w, h)
        else drawBars(canvas, w, h)
    }

    private fun drawBars(canvas: Canvas, w: Float, h: Float) {
        val data = fftData.takeIf { it.isNotEmpty() } ?: return
        val count = minOf(barCount, data.size / 2)
        val barW = w / count
        val gradient = LinearGradient(0f, h, 0f, 0f, gradientColors, null, Shader.TileMode.CLAMP)
        barPaint.shader = gradient

        for (i in 0 until count) {
            val magnitude = abs(data[i].toInt()).toFloat() / 128f
            val barH = magnitude * h * 0.9f + 4f
            val left = i * barW + 1f
            val right = left + barW - 2f
            canvas.drawRoundRect(left, h - barH, right, h, 4f, 4f, barPaint)
        }
    }

    private fun drawWave(canvas: Canvas, w: Float, h: Float) {
        val data = waveData.takeIf { it.isNotEmpty() } ?: return
        val path = Path()
        val step = w / data.size

        for (i in data.indices) {
            val x = i * step
            val y = h / 2 + (data[i].toInt() / 128f) * h / 2
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }

        barPaint.shader = LinearGradient(0f, 0f, w, 0f, gradientColors, null, Shader.TileMode.CLAMP)
        barPaint.style = Paint.Style.STROKE
        barPaint.strokeWidth = 3f
        canvas.drawPath(path, barPaint)
        barPaint.style = Paint.Style.FILL
    }

    fun release() {
        try { visualizer?.enabled = false; visualizer?.release() }
        catch (_: Exception) {}
        visualizer = null
    }
}
