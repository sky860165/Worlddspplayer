package com.audiolab.dspplayer.service

import android.app.*
import android.content.Intent
import android.os.Binder
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.audiolab.dspplayer.R
import com.audiolab.dspplayer.ui.VideoPlayerActivity

/**
 * VideoService: Keeps ExoPlayer alive in background so audio continues
 * playing even when app is minimized or screen is off.
 * PiP (Picture-in-Picture) is handled in VideoPlayerActivity itself.
 */
class VideoService : Service() {

    inner class VideoBinder : Binder() {
        fun getService() = this@VideoService
    }

    private val binder = VideoBinder()
    var player: ExoPlayer? = null
        private set

    companion object {
        const val CHANNEL_ID    = "video_playback_channel"
        const val NOTIF_ID      = 2
        const val ACTION_PLAY   = "video_action_play"
        const val ACTION_PAUSE  = "video_action_pause"
        const val ACTION_STOP   = "video_action_stop"
        var currentTitle: String = "Video"
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        initPlayer()
    }

    private fun initPlayer() {
        player = ExoPlayer.Builder(this).build().apply {
            addListener(object : Player.Listener {
                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    updateNotification()
                }
            })
        }
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PLAY  -> player?.play()
            ACTION_PAUSE -> player?.pause()
            ACTION_STOP  -> { releasePlayer(); stopSelf() }
        }
        return START_STICKY
    }

    fun playUri(uriString: String, title: String) {
        currentTitle = title
        val mediaItem = MediaItem.fromUri(uriString)
        player?.apply {
            setMediaItem(mediaItem)
            prepare()
            play()
        }
        startForeground(NOTIF_ID, buildNotification())
    }

    fun releasePlayer() {
        player?.release()
        player = null
        stopForeground(true)
    }

    private fun updateNotification() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildNotification())
    }

    private fun makePI(action: String): PendingIntent {
        val i = Intent(this, VideoService::class.java).apply { this.action = action }
        return PendingIntent.getService(
            this, 0, i,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }

    private fun buildNotification(): Notification {
        val openPI = PendingIntent.getActivity(
            this, 0,
            Intent(this, VideoPlayerActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val isPlaying = player?.isPlaying ?: false
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("🎬 $currentTitle")
            .setContentText(if (isPlaying) "Playing" else "Paused")
            .setSmallIcon(R.drawable.ic_play)
            .setContentIntent(openPI)
            .addAction(
                if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play,
                if (isPlaying) "Pause" else "Play",
                makePI(if (isPlaying) ACTION_PAUSE else ACTION_PLAY)
            )
            .addAction(R.drawable.ic_skip_next, "Stop", makePI(ACTION_STOP))
            .setOngoing(isPlaying)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(
                CHANNEL_ID, "Video Playback",
                NotificationManager.IMPORTANCE_LOW
            )
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(ch)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        releasePlayer()
    }
}
