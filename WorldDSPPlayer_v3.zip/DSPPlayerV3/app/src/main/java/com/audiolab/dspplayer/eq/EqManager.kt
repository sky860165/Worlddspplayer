package com.audiolab.dspplayer.eq

import android.content.Context
import android.content.SharedPreferences
import android.media.audiofx.*
import android.util.Log
import com.audiolab.dspplayer.model.CustomEqPreset
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class EqManager(private val context: Context) {

    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private var presetReverb: PresetReverb? = null
    private var loudnessEnhancer: LoudnessEnhancer? = null

    private val prefs: SharedPreferences =
        context.getSharedPreferences("dsp_prefs", Context.MODE_PRIVATE)
    private val gson = Gson()

    var numBands: Short = 10
        private set

    var bandMin: Short = -1500
        private set
    var bandMax: Short = 1500
        private set

    fun initialize(sessionId: Int) {
        release()
        try {
            equalizer = Equalizer(0, sessionId).apply {
                enabled = true
                numBands = numberOfBands
                // Fix: bandLevelRange() returns ShortArray, not callable like function
                val range: ShortArray = bandLevelRange
                bandMin = range[0]
                bandMax = range[1]
            }
            bassBoost = BassBoost(0, sessionId).apply { enabled = true }
            virtualizer = Virtualizer(0, sessionId).apply { enabled = true }
            presetReverb = PresetReverb(0, sessionId).apply { enabled = true }
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.KITKAT) {
                loudnessEnhancer = LoudnessEnhancer(sessionId).apply { enabled = false }
            }
            Log.d("EqManager", "DSP initialized, bands=$numBands")
        } catch (e: Exception) {
            Log.e("EqManager", "DSP init error: ${e.message}")
        }
    }

    fun getBandLevel(band: Int): Int = try {
        equalizer?.getBandLevel(band.toShort())?.toInt() ?: 0
    } catch (e: Exception) { 0 }

    fun setBandLevel(band: Int, level: Int) {
        try { equalizer?.setBandLevel(band.toShort(), level.toShort()) }
        catch (e: Exception) { Log.e("EqManager", "setBandLevel: ${e.message}") }
    }

    fun setBassBoost(strength: Int) {
        try { bassBoost?.setStrength(strength.toShort()) }
        catch (e: Exception) {}
    }

    fun setVirtualizer(strength: Int) {
        try { virtualizer?.setStrength(strength.toShort()) }
        catch (e: Exception) {}
    }

    fun setReverb(preset: Short) {
        try { presetReverb?.preset = preset }
        catch (e: Exception) {}
    }

    fun setLoudnessEnabled(enabled: Boolean, gainMb: Int = 0) {
        try {
            loudnessEnhancer?.enabled = enabled
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.KITKAT) {
                if (enabled) loudnessEnhancer?.setTargetGain(gainMb)
            }
        } catch (e: Exception) {}
    }

    fun applyBuiltinPreset(preset: EqualizerPresets.Preset) {
        try {
            val eq = equalizer ?: return
            val bands = eq.numberOfBands.toInt()
            for (i in 0 until minOf(bands, preset.bands.size)) {
                eq.setBandLevel(i.toShort(), preset.bands[i])
            }
            setBassBoost(preset.bassBoost.toInt())
            setVirtualizer(preset.virtualizer.toInt())
        } catch (e: Exception) { Log.e("EqManager", "applyPreset: ${e.message}") }
    }

    fun applyCustomPreset(preset: CustomEqPreset) {
        try {
            val eq = equalizer ?: return
            val bands = eq.numberOfBands.toInt()
            for (i in 0 until minOf(bands, preset.bands.size)) {
                eq.setBandLevel(i.toShort(), preset.bands[i].toShort())
            }
            setBassBoost(preset.bassBoost)
            setVirtualizer(preset.virtualizer)
        } catch (e: Exception) { Log.e("EqManager", "applyCustom: ${e.message}") }
    }

    fun getCurrentBands(): List<Int> {
        val eq = equalizer ?: return List(numBands.toInt()) { 0 }
        return (0 until eq.numberOfBands).map { eq.getBandLevel(it.toShort()).toInt() }
    }

    fun saveCustomPreset(preset: CustomEqPreset) {
        val all = loadAllCustomPresets().toMutableList()
        all.removeAll { it.name == preset.name }
        all.add(preset)
        prefs.edit().putString("custom_presets", gson.toJson(all)).apply()
    }

    fun loadAllCustomPresets(): List<CustomEqPreset> {
        val json = prefs.getString("custom_presets", null) ?: return emptyList()
        return try {
            val type = object : TypeToken<List<CustomEqPreset>>() {}.type
            gson.fromJson(json, type)
        } catch (e: Exception) { emptyList() }
    }

    fun deleteCustomPreset(name: String) {
        val all = loadAllCustomPresets().toMutableList()
        all.removeAll { it.name == name }
        prefs.edit().putString("custom_presets", gson.toJson(all)).apply()
    }

    fun release() {
        try { equalizer?.release() } catch (_: Exception) {}
        try { bassBoost?.release() } catch (_: Exception) {}
        try { virtualizer?.release() } catch (_: Exception) {}
        try { presetReverb?.release() } catch (_: Exception) {}
        try { loudnessEnhancer?.release() } catch (_: Exception) {}
        equalizer = null; bassBoost = null; virtualizer = null
        presetReverb = null; loudnessEnhancer = null
    }
}
