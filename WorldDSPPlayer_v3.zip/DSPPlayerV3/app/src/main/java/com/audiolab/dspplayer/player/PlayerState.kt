package com.audiolab.dspplayer.player

import android.net.Uri
import com.audiolab.dspplayer.model.Song

object PlayerState {
    var playlist: MutableList<Song> = mutableListOf()
    var currentIndex: Int = 0
    var isPlaying: Boolean = false
    var isShuffled: Boolean = false
    var repeatMode: RepeatMode = RepeatMode.NONE
    var currentPosition: Long = 0L

    val currentSong: Song? get() = playlist.getOrNull(currentIndex)

    enum class RepeatMode { NONE, ONE, ALL }
}
