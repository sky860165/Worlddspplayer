package com.audiolab.dspplayer.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.audiolab.dspplayer.R
import com.audiolab.dspplayer.model.VideoFile
import com.audiolab.dspplayer.util.VideoLoader
import com.bumptech.glide.Glide

class VideoListActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_VIDEO_LIST = "extra_video_list_index"
        const val PERM_CODE = 300
        var videoList: List<VideoFile> = emptyList()
    }

    private lateinit var recyclerView: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF0A0A0A.toInt())
        }

        // Toolbar
        val toolbar = TextView(this).apply {
            text = "🎬 Video Library"
            textSize = 20f
            setTextColor(0xFFE040FB.toInt())
            setPadding(48, 48, 48, 24)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        root.addView(toolbar)

        recyclerView = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@VideoListActivity)
            setPadding(0, 8, 0, 8)
        }
        root.addView(recyclerView, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        setContentView(root)

        checkPermissionsAndLoad()
    }

    private fun checkPermissionsAndLoad() {
        val needed = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_VIDEO)
                != PackageManager.PERMISSION_GRANTED)
                needed.add(Manifest.permission.READ_MEDIA_VIDEO)
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED)
                needed.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        if (needed.isNotEmpty())
            ActivityCompat.requestPermissions(this, needed.toTypedArray(), PERM_CODE)
        else loadVideos()
    }

    override fun onRequestPermissionsResult(rc: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(rc, perms, results)
        if (rc == PERM_CODE) loadVideos()
    }

    private fun loadVideos() {
        videoList = VideoLoader.loadAllVideos(this)
        if (videoList.isEmpty()) {
            Toast.makeText(this, "No videos found on device", Toast.LENGTH_LONG).show()
        }
        recyclerView.adapter = VideoAdapter(videoList) { index ->
            val intent = Intent(this, VideoPlayerActivity::class.java)
            intent.putExtra(EXTRA_VIDEO_LIST, index)
            startActivity(intent)
        }
    }
}

class VideoAdapter(
    private val videos: List<VideoFile>,
    private val onItemClick: (Int) -> Unit
) : RecyclerView.Adapter<VideoAdapter.VH>() {

    inner class VH(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val thumb: ImageView = itemView.findViewById(101)
        val title: TextView  = itemView.findViewById(102)
        val info: TextView   = itemView.findViewById(103)
        val badge: TextView  = itemView.findViewById(104)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val ctx = parent.context

        val card = androidx.cardview.widget.CardView(ctx).apply {
            layoutParams = RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).also { it.setMargins(16, 8, 16, 8) }
            radius = 16f
            setCardBackgroundColor(0xFF1A1A1A.toInt())
            cardElevation = 4f
        }

        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(16, 16, 16, 16)
            gravity = android.view.Gravity.CENTER_VERTICAL
        }

        val thumb = ImageView(ctx).apply {
            id = 101
            layoutParams = LinearLayout.LayoutParams(160, 100)
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(0xFF222222.toInt())
        }
        row.addView(thumb)

        val textBlock = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).also {
                it.marginStart = 16
            }
        }

        val title = TextView(ctx).apply {
            id = 102
            textSize = 14f
            setTextColor(0xFFFFFFFF.toInt())
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            maxLines = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        val info = TextView(ctx).apply {
            id = 103
            textSize = 12f
            setTextColor(0xFF9E9E9E.toInt())
        }
        val badge = TextView(ctx).apply {
            id = 104
            textSize = 10f
            setTextColor(0xFFE040FB.toInt())
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(12, 4, 12, 4)
            setBackgroundColor(0x22E040FB)
        }
        textBlock.addView(title)
        textBlock.addView(info)
        textBlock.addView(badge)
        row.addView(textBlock)
        card.addView(row)

        return VH(card).also { vh ->
            card.setOnClickListener { onItemClick(vh.adapterPosition) }
        }
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val v = videos[position]
        holder.title.text = v.title
        holder.info.text  = "${v.formattedDuration()} • ${v.formattedSize()}"
        holder.badge.text = v.resolution()
        if (v.thumbnailUri != null) {
            Glide.with(holder.thumb.context)
                .load(v.thumbnailUri)
                .centerCrop()
                .placeholder(android.R.drawable.ic_media_play)
                .into(holder.thumb)
        }
    }

    override fun getItemCount() = videos.size
}
