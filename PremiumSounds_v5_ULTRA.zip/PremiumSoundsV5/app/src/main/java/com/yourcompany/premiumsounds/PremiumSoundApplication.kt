package com.yourcompany.premiumsounds

import android.app.Application
import android.content.Intent
import android.os.Build
import com.yourcompany.premiumsounds.audio.GlobalAudioEffectService

class PremiumSoundApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        // Auto-start the global EQ service when app launches
        val intent = Intent(this, GlobalAudioEffectService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }
}
