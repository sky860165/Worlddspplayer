package com.yourcompany.premiumsounds.audio

import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

data class Track(
    val id: String,
    val title: String,
    val artist: String,
    val album: String,
    val uri: String,
    val durationMs: Long = 0L,
    val format: String = "Unknown"
)

class PlaylistManager {

    private val _playlist = MutableStateFlow<List<Track>>(emptyList())
    val playlist: StateFlow<List<Track>> = _playlist

    private val _currentIndex = MutableStateFlow(0)
    val currentIndex: StateFlow<Int> = _currentIndex

    /**
     * The playlist starts empty. Real tracks are added via [addTracks] after
     * scanning the device library with [DeviceMusicScanner], so the app only
     * ever plays files that actually exist instead of broken placeholder paths.
     */

    fun addTracks(tracks: List<Track>) {
        val existingIds = _playlist.value.map { it.id }.toSet()
        val newOnes = tracks.filter { it.id !in existingIds }
        _playlist.value = _playlist.value + newOnes
    }

    fun clear() {
        _playlist.value = emptyList()
        _currentIndex.value = 0
    }

    fun setCurrentIndex(index: Int) {
        if (_playlist.value.isEmpty()) {
            _currentIndex.value = 0
            return
        }
        _currentIndex.value = index.coerceIn(0, _playlist.value.lastIndex)
    }

    fun currentTrack(): Track? = _playlist.value.getOrNull(_currentIndex.value)

    fun addTrack(track: Track) {
        _playlist.value = _playlist.value + track
    }

    fun removeTrack(id: String) {
        val updated = _playlist.value.filter { it.id != id }
        _playlist.value = updated
        _currentIndex.value = _currentIndex.value.coerceIn(0, (updated.size - 1).coerceAtLeast(0))
    }

    fun moveTrack(fromIndex: Int, toIndex: Int) {
        val list = _playlist.value.toMutableList()
        if (fromIndex !in list.indices || toIndex !in list.indices) return
        val item = list.removeAt(fromIndex)
        list.add(toIndex, item)
        _playlist.value = list
    }

    fun toMediaItems(): List<MediaItem> = _playlist.value.map { track ->
        val uri = android.net.Uri.parse(track.uri)
        MediaItem.Builder()
            .setUri(uri)                          // sets localConfiguration.uri directly
            .setMediaId(track.id)
            .setRequestMetadata(
                androidx.media3.common.MediaItem.RequestMetadata.Builder()
                    .setMediaUri(uri)
                    .build()
            )
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(track.title)
                    .setArtist(track.artist)
                    .setAlbumTitle(track.album)
                    .build()
            )
            .build()
    }

    fun nextIndex(): Int {
        val size = _playlist.value.size
        return if (size == 0) 0 else (_currentIndex.value + 1) % size
    }

    fun prevIndex(): Int {
        val size = _playlist.value.size
        return if (size == 0) 0 else (_currentIndex.value - 1 + size) % size
    }
}
