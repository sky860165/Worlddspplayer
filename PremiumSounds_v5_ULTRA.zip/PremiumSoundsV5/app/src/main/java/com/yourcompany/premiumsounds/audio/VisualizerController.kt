package com.yourcompany.premiumsounds.audio

import android.media.audiofx.Visualizer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class VisualizerController {

    private var visualizer: Visualizer? = null

    private val _waveform = MutableStateFlow(ByteArray(128))
    val waveform: StateFlow<ByteArray> = _waveform

    private val _fft = MutableStateFlow(ByteArray(128))
    val fft: StateFlow<ByteArray> = _fft

    private val _isActive = MutableStateFlow(false)
    val isActive: StateFlow<Boolean> = _isActive

    fun attach(audioSessionId: Int) {
        release()
        try {
            val captureSize = Visualizer.getCaptureSizeRange()[1]
                .coerceAtMost(1024)
                .coerceAtLeast(Visualizer.getCaptureSizeRange()[0])

            visualizer = Visualizer(audioSessionId).apply {
                setCaptureSize(captureSize)
                setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                    override fun onWaveFormDataCapture(v: Visualizer?, waveform: ByteArray?, samplingRate: Int) {
                        waveform?.let { _waveform.value = it.copyOf(128.coerceAtMost(it.size)) }
                    }
                    override fun onFftDataCapture(v: Visualizer?, fft: ByteArray?, samplingRate: Int) {
                        fft?.let { _fft.value = it.copyOf(128.coerceAtMost(it.size)) }
                    }
                }, Visualizer.getMaxCaptureRate() / 2, true, true)
                enabled = true
            }
            _isActive.value = true
        } catch (e: Exception) {
            e.printStackTrace()
            _isActive.value = false
        }
    }

    fun release() {
        try {
            visualizer?.enabled = false
            visualizer?.release()
        } catch (_: Exception) {}
        visualizer = null
        _isActive.value = false
    }
}
