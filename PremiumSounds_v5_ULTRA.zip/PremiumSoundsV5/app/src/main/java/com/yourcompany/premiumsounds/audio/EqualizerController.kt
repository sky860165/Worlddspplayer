package com.yourcompany.premiumsounds.audio

import android.media.audiofx.Equalizer
import android.media.audiofx.BassBoost
import android.media.audiofx.Virtualizer
import android.media.audiofx.LoudnessEnhancer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class EqualizerController {

    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private var loudnessEnhancer: LoudnessEnhancer? = null

    private val _eqState = MutableStateFlow(EqState())
    val eqState: StateFlow<EqState> = _eqState

    data class EqState(
        val bands: List<BandState> = emptyList(),
        val currentPreset: String = "Custom",
        val bassStrength: Int = 0,       // 0–1000
        val virtualizerStrength: Int = 0, // 0–1000
        val premiumBoostMb: Int = 0,      // 0–2000 milli-dB, Premium Loudness Boost
        val isEnabled: Boolean = false
    )

    data class BandState(
        val index: Int,
        val centerFreqHz: Int,
        val levelMb: Int,   // milli-Bel, range typically -1500..+1500
        val minLevelMb: Int,
        val maxLevelMb: Int
    )

    val presets = mapOf(
        "Flat"       to listOf(0, 0, 0, 0, 0),
        "Bass Boost" to listOf(800, 400, 0, 0, 0),
        "Treble"     to listOf(0, 0, 0, 400, 800),
        "Vocal"      to listOf(-200, 0, 600, 400, 0),
        "Rock"       to listOf(500, 300, -100, 300, 500),
        "Pop"        to listOf(-100, 300, 500, 300, -100),
        "Classical"  to listOf(300, 200, -200, 200, 300),
        "Custom"     to listOf(0, 0, 0, 0, 0)
    )

    fun attach(audioSessionId: Int) {
        release()
        try {
            equalizer = Equalizer(0, audioSessionId).apply { enabled = true }
            bassBoost = BassBoost(0, audioSessionId).apply { enabled = true }
            virtualizer = Virtualizer(0, audioSessionId).apply { enabled = true }
            loudnessEnhancer = LoudnessEnhancer(audioSessionId).apply {
                setTargetGain(_eqState.value.premiumBoostMb)
                enabled = _eqState.value.premiumBoostMb > 0
            }
            refreshState()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun setBandLevel(bandIndex: Int, levelMb: Int) {
        val eq = equalizer ?: return
        try {
            eq.setBandLevel(bandIndex.toShort(), levelMb.toShort())
            refreshState(preset = "Custom")
        } catch (_: Exception) {}
    }

    fun applyPreset(presetName: String) {
        val levels = presets[presetName] ?: return
        val eq = equalizer ?: return
        val bandCount = eq.numberOfBands.toInt()
        levels.take(bandCount).forEachIndexed { i, level ->
            try { eq.setBandLevel(i.toShort(), level.toShort()) } catch (_: Exception) {}
        }
        refreshState(preset = presetName)
    }

    fun setBassStrength(strength: Int) {
        try {
            bassBoost?.setStrength(strength.toShort())
            _eqState.value = _eqState.value.copy(bassStrength = strength)
        } catch (_: Exception) {}
    }

    fun setVirtualizerStrength(strength: Int) {
        try {
            virtualizer?.setStrength(strength.toShort())
            _eqState.value = _eqState.value.copy(virtualizerStrength = strength)
        } catch (_: Exception) {}
    }

    /**
     * Premium Loudness Boost — adds extra clean gain (via LoudnessEnhancer)
     * on top of normal volume, useful for quiet recordings or weak phone
     * speakers. Range is 0–2000 milli-dB (0–20 dB).
     */
    fun setPremiumBoost(gainMb: Int) {
        try {
            loudnessEnhancer?.setTargetGain(gainMb)
            loudnessEnhancer?.enabled = gainMb > 0
            _eqState.value = _eqState.value.copy(premiumBoostMb = gainMb)
        } catch (_: Exception) {}
    }

    fun setEnabled(enabled: Boolean) {
        equalizer?.enabled = enabled
        bassBoost?.enabled = enabled
        virtualizer?.enabled = enabled
        loudnessEnhancer?.enabled = enabled && _eqState.value.premiumBoostMb > 0
        _eqState.value = _eqState.value.copy(isEnabled = enabled)
    }

    private fun refreshState(preset: String? = null) {
        val eq = equalizer ?: return
        val bandCount = eq.numberOfBands.toInt()
        val levelRange = eq.bandLevelRange

        val bands = (0 until bandCount).map { i ->
            BandState(
                index = i,
                centerFreqHz = eq.getCenterFreq(i.toShort()) / 1000,
                levelMb = eq.getBandLevel(i.toShort()).toInt(),
                minLevelMb = levelRange[0].toInt(),
                maxLevelMb = levelRange[1].toInt()
            )
        }

        _eqState.value = _eqState.value.copy(
            bands = bands,
            currentPreset = preset ?: _eqState.value.currentPreset,
            isEnabled = eq.enabled
        )
    }

    fun release() {
        try { equalizer?.release() } catch (_: Exception) {}
        try { bassBoost?.release() } catch (_: Exception) {}
        try { virtualizer?.release() } catch (_: Exception) {}
        try { loudnessEnhancer?.release() } catch (_: Exception) {}
        equalizer = null
        bassBoost = null
        virtualizer = null
        loudnessEnhancer = null
    }
}
