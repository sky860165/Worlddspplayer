package com.yourcompany.premiumsounds.audio

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore

data class VideoTrack(
    val id: String,
    val title: String,
    val duration: Long,
    val size: Long,
    val width: Int,
    val height: Int,
    val uri: Uri,
    val mimeType: String
) {
    val is4K get() = width >= 3840 || height >= 2160
    val isFullHD get() = (width >= 1920 || height >= 1080) && !is4K
    val isHD get() = (width >= 1280 || height >= 720) && !isFullHD && !is4K
    val qualityLabel get() = when { is4K -> "4K"; isFullHD -> "FHD"; isHD -> "HD"; else -> "SD" }
    val resolution get() = "${width}x${height}"
    val sizeLabel get() = when {
        size > 1_000_000_000L -> "%.1f GB".format(size / 1_000_000_000.0)
        size > 1_000_000L -> "%.0f MB".format(size / 1_000_000.0)
        else -> "%.0f KB".format(size / 1_000.0)
    }
}

object DeviceVideoScanner {
    fun scan(context: Context): List<VideoTrack> {
        val list = mutableListOf<VideoTrack>()
        val col = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q)
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        else MediaStore.Video.Media.EXTERNAL_CONTENT_URI

        val proj = arrayOf(
            MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION, MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.WIDTH, MediaStore.Video.Media.HEIGHT,
            MediaStore.Video.Media.MIME_TYPE
        )
        try {
            context.contentResolver.query(col, proj, null, null,
                "${MediaStore.Video.Media.DATE_MODIFIED} DESC")?.use { c ->
                val iId = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val iName = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val iDur = c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val iSize = c.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                val iW = c.getColumnIndexOrThrow(MediaStore.Video.Media.WIDTH)
                val iH = c.getColumnIndexOrThrow(MediaStore.Video.Media.HEIGHT)
                val iMime = c.getColumnIndexOrThrow(MediaStore.Video.Media.MIME_TYPE)
                while (c.moveToNext()) {
                    val id = c.getLong(iId)
                    list.add(VideoTrack(
                        id = id.toString(),
                        title = (c.getString(iName) ?: "Video").substringBeforeLast('.'),
                        duration = c.getLong(iDur),
                        size = c.getLong(iSize),
                        width = c.getInt(iW),
                        height = c.getInt(iH),
                        uri = ContentUris.withAppendedId(col, id),
                        mimeType = c.getString(iMime) ?: "video/mp4"
                    ))
                }
            }
        } catch (e: Exception) { e.printStackTrace() }
        return list
    }
}
