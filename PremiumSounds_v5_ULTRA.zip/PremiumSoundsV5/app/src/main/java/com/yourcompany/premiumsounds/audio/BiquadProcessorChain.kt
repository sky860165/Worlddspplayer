package com.yourcompany.premiumsounds.audio

import androidx.media3.common.audio.AudioProcessor
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.exoplayer.audio.SonicAudioProcessor

/**
 * BiquadProcessorChain
 * Custom AudioProcessorChain that puts our 20-band EQ in the pipeline,
 * followed by SonicAudioProcessor (required for speed/pitch control).
 *
 * Bypasses DefaultAudioProcessorChain to guarantee injection.
 */
@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
class BiquadProcessorChain(
    private val biquadEQ: BiquadEQProcessor
) : DefaultAudioSink.AudioProcessorChain {

    private val sonic = SonicAudioProcessor()

    // ExoPlayer calls this to get ALL processors in order
    override fun getAudioProcessors(): Array<AudioProcessor> {
        return arrayOf(biquadEQ, sonic)
    }

    // Speed/pitch — delegate to Sonic
    override fun applyPlaybackSpeed(playbackSpeed: Float): Float {
        sonic.setSpeed(playbackSpeed)
        sonic.setPitch(playbackSpeed)
        return sonic.speed
    }

    override fun applySkipSilenceEnabled(skipSilenceEnabled: Boolean): Boolean {
        // silence skipping — not needed for EQ
        return skipSilenceEnabled
    }

    override fun getMediaDuration(playoutDuration: Long): Long {
        return sonic.getMediaDuration(playoutDuration)
    }

    override fun getSkippedOutputFrameCount(): Long = 0L
}
