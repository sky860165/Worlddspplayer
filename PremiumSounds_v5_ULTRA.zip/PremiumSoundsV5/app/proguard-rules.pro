# Add project specific ProGuard rules here.
# Keep Media3 / ExoPlayer classes used via reflection.
-keep class androidx.media3.** { *; }
-dontwarn androidx.media3.**

# Keep Compose runtime
-keep class androidx.compose.** { *; }

# Keep our data/model classes (Track, EqState, etc.)
-keep class com.yourcompany.premiumsounds.audio.** { *; }
