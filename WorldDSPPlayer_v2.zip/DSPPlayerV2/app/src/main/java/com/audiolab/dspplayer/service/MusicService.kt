package com.audiolab.dspplayer.service

import android.app.*
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.PlaybackParams
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.support.v4.media.session.MediaSessionCompat
import androidx.core.app.NotificationCompat
import com.audiolab.dspplayer.R
import com.audiolab.dspplayer.eq.EqManager
import com.audiolab.dspplayer.eq.EqualizerPresets
import com.audiolab.dspplayer.model.CustomEqPreset
import com.audiolab.dspplayer.model.Song
import com.audiolab.dspplayer.player.PlayerState
import com.audiolab.dspplayer.ui.MainActivity

class MusicService : Service() {

    inner class MusicBinder : Binder() {
        fun getService() = this@MusicService
    }

    private val binder = MusicBinder()
    private var mediaPlayer: MediaPlayer? = null
    lateinit var eqManager: EqManager

    private var mediaSession: MediaSessionCompat? = null
    private var sleepTimerRunnable: Runnable? = null
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())

    var onPlaybackChanged: (() -> Unit)? = null
    var onProgressUpdate: ((Int, Int) -> Unit)? = null
    var currentSpeed: Float = 1.0f
    var currentBalance: Float = 0f

    companion object {
        const val CHANNEL_ID = "dsp_music_channel"
        const val NOTIF_ID = 1
        const val ACTION_PLAY = "action_play"
        const val ACTION_PAUSE = "action_pause"
        const val ACTION_NEXT = "action_next"
        const val ACTION_PREV = "action_prev"
        const val ACTION_STOP = "action_stop"
    }

    override fun onCreate() {
        super.onCreate()
        eqManager = EqManager(this)  // context valid hai ab
        createNotificationChannel()
        mediaSession = MediaSessionCompat(this, "DSPPlayer")
        startProgressUpdater()
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PLAY -> if (!isPlaying()) play()
            ACTION_PAUSE -> if (isPlaying()) pause()
            ACTION_NEXT -> next()
            ACTION_PREV -> previous()
            ACTION_STOP -> { stop(); stopSelf() }
        }
        return START_STICKY
    }

    fun playSong(song: Song) {
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
            mediaPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
                setDataSource(this@MusicService, song.uri)
                prepare()
                setOnCompletionListener { onSongComplete() }
                start()
            }
            val sessionId = mediaPlayer!!.audioSessionId
            eqManager.initialize(sessionId)
            applySpeed()
            PlayerState.isPlaying = true
            showNotification(song)
            onPlaybackChanged?.invoke()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun play() {
        mediaPlayer?.start()
        PlayerState.isPlaying = true
        PlayerState.currentSong?.let { showNotification(it) }
        onPlaybackChanged?.invoke()
    }

    fun pause() {
        mediaPlayer?.pause()
        PlayerState.isPlaying = false
        PlayerState.currentSong?.let { showNotification(it) }
        onPlaybackChanged?.invoke()
    }

    fun stop() {
        mediaPlayer?.stop()
        mediaPlayer?.release()
        mediaPlayer = null
        eqManager.release()
        PlayerState.isPlaying = false
        stopForeground(true)
    }

    fun next() {
        val playlist = PlayerState.playlist
        if (playlist.isEmpty()) return
        if (PlayerState.isShuffled) {
            PlayerState.currentIndex = (0 until playlist.size).random()
        } else {
            PlayerState.currentIndex = (PlayerState.currentIndex + 1) % playlist.size
        }
        playSong(playlist[PlayerState.currentIndex])
    }

    fun previous() {
        val playlist = PlayerState.playlist
        if (playlist.isEmpty()) return
        PlayerState.currentIndex = if (PlayerState.currentIndex > 0)
            PlayerState.currentIndex - 1 else playlist.size - 1
        playSong(playlist[PlayerState.currentIndex])
    }

    fun seekTo(ms: Int) { mediaPlayer?.seekTo(ms) }
    fun getDuration(): Int = mediaPlayer?.duration ?: 0
    fun getCurrentPosition(): Int = mediaPlayer?.currentPosition ?: 0
    fun isPlaying(): Boolean = mediaPlayer?.isPlaying ?: false

    fun setSpeed(s: Float) {
        currentSpeed = s
        applySpeed()
    }

    private fun applySpeed() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                mediaPlayer?.playbackParams = PlaybackParams().apply {
                    speed = this@MusicService.currentSpeed
                }
            } catch (_: Exception) {}
        }
    }

    fun setBalance(bal: Float) {
        currentBalance = bal
        val left = if (bal < 0) 1f else 1f - bal
        val right = if (bal > 0) 1f else 1f + bal
        try { mediaPlayer?.setVolume(left.coerceIn(0f,1f), right.coerceIn(0f,1f)) } catch (_: Exception) {}
    }

    fun setSleepTimer(minutes: Int) {
        sleepTimerRunnable?.let { handler.removeCallbacks(it) }
        sleepTimerRunnable = Runnable { pause() }
        handler.postDelayed(sleepTimerRunnable!!, minutes * 60 * 1000L)
    }

    fun cancelSleepTimer() {
        sleepTimerRunnable?.let { handler.removeCallbacks(it) }
        sleepTimerRunnable = null
    }

    fun applyBuiltinPreset(preset: EqualizerPresets.Preset) = eqManager.applyBuiltinPreset(preset)
    fun applyCustomPreset(preset: CustomEqPreset) = eqManager.applyCustomPreset(preset)

    private fun onSongComplete() {
        when (PlayerState.repeatMode) {
            PlayerState.RepeatMode.ONE -> playSong(PlayerState.currentSong!!)
            PlayerState.RepeatMode.ALL -> next()
            PlayerState.RepeatMode.NONE -> if (PlayerState.currentIndex < PlayerState.playlist.size - 1) next()
            else { PlayerState.isPlaying = false; onPlaybackChanged?.invoke() }
        }
    }

    private fun startProgressUpdater() {
        val r = object : Runnable {
            override fun run() {
                onProgressUpdate?.invoke(getCurrentPosition(), getDuration())
                handler.postDelayed(this, 500)
            }
        }
        handler.post(r)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "Music Playback", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
    }

    private fun makeIntent(action: String): PendingIntent {
        val i = Intent(this, MusicService::class.java).apply { this.action = action }
        return PendingIntent.getService(this, 0, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun showNotification(song: Song) {
        val openIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val notif = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(song.title)
            .setContentText(song.artist)
            .setSmallIcon(R.drawable.ic_music_note)
            .setContentIntent(openIntent)
            .addAction(R.drawable.ic_skip_prev, "Prev", makeIntent(ACTION_PREV))
            .addAction(
                if (PlayerState.isPlaying) R.drawable.ic_pause else R.drawable.ic_play,
                if (PlayerState.isPlaying) "Pause" else "Play",
                makeIntent(if (PlayerState.isPlaying) ACTION_PAUSE else ACTION_PLAY)
            )
            .addAction(R.drawable.ic_skip_next, "Next", makeIntent(ACTION_NEXT))
            .setStyle(
                androidx.media.app.NotificationCompat.MediaStyle()
                    .setShowActionsInCompactView(0, 1, 2)
                    .setMediaSession(mediaSession?.sessionToken)
            )
            .setOngoing(PlayerState.isPlaying)
            .build()
        startForeground(NOTIF_ID, notif)
    }

    override fun onDestroy() {
        super.onDestroy()
        stop()
        mediaSession?.release()
        handler.removeCallbacksAndMessages(null)
    }
}
